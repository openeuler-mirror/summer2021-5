=====================================================
Instructions for a Multiple Server Swift Installation
=====================================================

Please refer to the latest official
`OpenStack Installation Guides <https://docs.openstack.org/latest/install/>`_
for the most up-to-date documentation.

Current Install Guides
----------------------

* `Object Storage installation guide for OpenStack Ocata
  <https://docs.openstack.org/project-install-guide/object-storage/ocata/>`__
* `Object Storage installation guide for OpenStack Newton
  <https://docs.openstack.org/project-install-guide/object-storage/newton/>`__
